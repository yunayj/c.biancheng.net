#ifndef TOOL_H
#define TOOL_H
#define file_name "student.txt"
#define tempFile_name "student_temp.txt"
#endif // TOOL_H
